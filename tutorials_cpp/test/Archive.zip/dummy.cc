#include <vector>
#include <iostream>
#include <memory>
#include <algorithm>

using namespace std;

class A
{
public:
    A(int a): a_(a) {}
    int a_;
};

int x[11];

bool operator<(const A &a, const A &b)
{
    return x[a.a_] < x[b.a_];
}

class Comp
{
public:
    bool operator()(const A &a, const A &b)
    {
        return x[a.a_] > x[b.a_];
    }
};


int main(int argc, char const *argv[])
{
    int i = 1;
    for_each(x, x + 11, [&](int &val)
    {
        val = i++;
    });


    std::vector< A > v;
    v.push_back(10);
    v.push_back(5);
    v.push_back(7);
    v.push_back(1);
    v.push_back(3);

    // std::make_heap(v.begin(), v.end());
    // cout << v.front().a_;

    Comp comp;
    std::make_heap(v.begin(), v.end(), comp);
    cout << v.front().a_;
	
	std::pop_heap(v.begin(), v.end()); v.pop_back();
    // std::make_heap(v.begin(), v.end(), comp);
    cout << v.front().a_;


    cout << endl;



    // std::vector< std::shared_ptr<A> > v;
    // std::shared_ptr<A> p(new A());
    // v.push_back(p);
    // p.reset(new A());
    // v.push_back(p);
    // for_each(v.begin(), v.end(), [](const std::shared_ptr<A>& ptr) {cout << ptr.use_count() << endl;}
    //  );
    // for (std::vector< std::shared_ptr<A> >::iterator i = v.begin(); i != v.end(); ++i)
    // {
    //  cout << (*i).use_count() << endl;
    // }

    // std::shared_ptr<const A> v;
    return 0;
}