#ifndef __MIDDLE_TYPE_H__
#define __MIDDLE_TYPE_H__

template <class T>
T middle(T a, T b);

#endif // __MIDDLE_TYPE_H__
