#include "HuffmanAlg.hh"

#include <iostream>

using namespace std;

int main(int argc, char const *argv[])
{
    HuffmanAlg huff("Ramakrishnan");
    huff.solve();
    cout << huff.code();
    string s = huff.encodedText();
    cout << "Encoded Text : " << s;
    cout << huff.decode(s);
    return 0;
}
// #include <iostream>

// using namespace std;

// class B
// {
//     // int i; // Line:1
//     static int j;
// public:
//     void g()
//     {
//         // i = 9; // Line:2
//         cout << "g() " << this << " " << j << " \n";
//     }
// };

// int B::j = 100;

// int main()
// {
//     B *x = NULL;
//     x->g(); // supposed to throw error
//     x = new B();
//     x->g();

//     unique_ptr<B> y;
//     y->g();
//     if (!y)
//     {
//      cout << "no y \n";
//     }
//     y.reset(new B());
//     y->g();

// }
// #include <iostream>
// using namespace std;

// int main(int argc, char const *argv[])
// {
//  string s;
//  char c[100];
//  cin.clear();
//  cout << "Enter:";
//  scanf("{%[^}]", c);
//  cout << "c: " << c << endl;
//  return 0;
// }

// #include <iostream>
// #include <string>
// #include <memory>
// #include <map>
// using namespace std;

// /// compare first with variable length list
// /// Usage: is_one_of(first, N, item0, item1, ... itemN)
// bool is_one_of(int first, int n_args, ...)
// {
//     va_list ap;
//     va_start(ap, n_args);
//     auto is_match = false;
//     for(auto i = 1; !is_match && i <= n_args; i++)
//     {
//         is_match = is_match || first == va_arg(ap, int);
//     }
//     va_end(ap);
//     return is_match;
// }
// bool is_one_of(float first, int n_args, ...)
// {
//     va_list ap;
//     va_start(ap, n_args);
//     auto is_match = false;
//     for(auto i = 1; !is_match && i <= n_args; i++)
//     {
//         is_match = is_match || first == va_arg(ap, int);
//     }
//     va_end(ap);
//     return is_match;
// }

// int main(int argc, char const *argv[])
// {
//  cout<<std::boolalpha;
//  cout<<is_one_of(6, 3, 1, 6, 3)<<"\n";
//  cout<<is_one_of(6, 3, 1, 6.0, 4)<<"\n";
//  cout<<is_one_of(6, 3, 1, 6.0)<<"\n";
//  cout<<is_one_of(6.0, 3, 1, 6, 3)<<"\n";
//  cout<<is_one_of(6.0, 3, 1, 6.0, 4)<<"\n";
//  cout<<is_one_of(6.0, 3, 1, 6.0)<<"\n";
//  return 0;
// }