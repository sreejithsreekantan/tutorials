/*
	Author		:		Sreejith Sreekantan
	
*/


#include <iostream>
#include <set>
#include <memory>
#include <sstream>
#include "Graph.h"

using namespace std;
// using namespace graph;

int main(int argc, char const *argv[])
{
	istringstream in;
	in.str(
			"	13		\
				13		\
				0 5 	\
				4 3 	\
				0 1 	\
				9 12 	\
				6 4 	\
				5 4 	\
				0 2 	\
				11 12 	\
				9 10 	\
				0 6 	\
				7 8 	\
				9 11 	\
				5 3 	\
			"
		);
	unique_ptr<Graph> graph(getGraphFromIStream(in));
	putGraphToOStream(*graph, cout);

	const set<int>& set_neigh = graph->edgesOf(0);
	// set_neigh.insert(100); // will cause error; just to clear the doubt of break of encapsulation

	putGraphToOStream(*graph, cout);
	return 0;
}
